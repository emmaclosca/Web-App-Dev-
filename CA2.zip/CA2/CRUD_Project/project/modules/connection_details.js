var user= 'root';
var password = 'password';
var host = 'localhost';
var database = 'gamestore';

module.exports = {user:user, password: password, host: host, database:database};