DROP DATABASE IF EXISTS gamestore;

CREATE DATABASE gamestore;

USE gamestore;

CREATE TABLE `items`
  (
     `item_name`    VARCHAR(255) PRIMARY KEY,
     `item_category`VARCHAR(255),
     `item_price`    INTEGER NOT NULL,
     `item_id`    INTEGER NOT NULL
     
     
  );

CREATE TABLE `customer`
  (
    `customer_name`    VARCHAR(200) PRIMARY KEY NOT NULL,
     `customer_address` VARCHAR(30) NOT NULL,
     `customer_id`    INTEGER NOT NULL,
     `phonenumber`      VARCHAR(30) NOT NULL
    
  );

CREATE TABLE `stores`
  (
	 `store_name`   VARCHAR(200) PRIMARY KEY NOT NULL,
     `store_id`    INTEGER NOT NULL,
     `city`         VARCHAR(30) NOT NULL,
     `manager_name` VARCHAR(30) NOT NULL
     
  );
  CREATE TABLE `employee`
  (
     `employee_name`   VARCHAR(200) PRIMARY KEY NOT NULL,
     `employee_gender` VARCHAR(30) NOT NULL,
     `employee_age`    VARCHAR(30) NOT NULL,
     `employee_id`    INTEGER NOT NULL,
     `location`        VARCHAR(20) NOT NULL,
     FOREIGN KEY(location) REFERENCES stores (store_name)
  );

CREATE TABLE `sales`
  (
     `saleid`     INTEGER NOT NULL PRIMARY KEY AUTO_INCREMENT,
     `sale_total` VARCHAR(200) NOT NULL,
     `quantity`   VARCHAR(30) NOT NULL,
     `item_name`   VARCHAR(200),
     `store_name`    VARCHAR(200),
     `employee_name`  VARCHAR(200),
     `customer_name` VARCHAR(200),
     FOREIGN KEY(item_name) REFERENCES items(item_name),
     FOREIGN KEY(store_name) REFERENCES stores (store_name),
	   FOREIGN KEY(employee_name) REFERENCES employee (employee_name),
     FOREIGN KEY(customer_name) REFERENCES customer (customer_name)
  ); 
  
  
  