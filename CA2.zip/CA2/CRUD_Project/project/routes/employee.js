var express = require('express');
var router = express.Router();
var MySql = require('sync-mysql');
/* this function was adapted from lectururs work */
var connection_details = require("../modules/connection_details")
/* this will render the Employee table on the ejs file */

router.get('/', function(req, res, next) {
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var employee = connection.query("SELECT * from employee");


    res.render('employee', {
        employee: employee
    });


});
/* this add function will recieve from the ejs file all the variables we want to add into our sql table for employees and then uses a query to insert them */

router.post('/add', function(req, res, next) {

    var employee_name = req.body.employee_name
    var employee_gender = req.body.employee_gender
    var employee_age = req.body.employee_age
    var employee_id = req.body.employee_id
    var location = req.body.location
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    })
    connection.query("INSERT INTO employee (employee_name, employee_gender, employee_age, employee_id, location) VALUES ((?), (?), (?), (?), (?));", [employee_name, employee_gender, employee_age, employee_id, location]);
    res.redirect("/employee");
})

/* this delete function recieves the employee id and then deletes that id from the database along with the row that its connected to */

router.get('/delete', function(req, res, next) {

    var employee_id = req.query.employee_id

    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });

    var employee = connection.query("SELECT * from employee");
    res.render('employee', {
        title: 'delete page',
        employee: employee
    });
    connection.query("DELETE FROM employee where employee_id = (?);", [employee_id])
    res.redirect('/employee')
})
/* this recieves the employee id from the ejs file and also renders the employee info on the page  */

router.get('/update', function(req, res, next) {
    var employee_id = req.query.employee_id
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var employee = connection.query("SELECT * from employee");

    res.render('employee', {
        employee: employee,
        employee_id: employee_id
    });

})
/* this update function was adapted from lectururs work */
/* this will recieve all the variables for the data i want to update then pushes that data to the sql table */
router.post('/update', function(req, res, next) {
    var employee_name = req.body.employee_name
    var employee_gender = req.body.employee_gender
    var employee_age = req.body.employee_age
    var employee_id = req.body.employee_id
    var location = req.body.location
    var connection = new MySql({
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database,
        host: connection_details.host
    })
    var query_string = "UPDATE employee set"
    var params = []
    if (employee_name) {
        query_string += ' employee_name = (?)'
        params.push(employee_name)
    }
    if (employee_gender) {
        if (employee_name || employee_age || employee_id || location) {
            query_string += ", "
        }
        query_string += ' employee_gender = (?) '
        params.push(employee_gender)
    }
    if (employee_age) {
        if (employee_name || employee_gender || employee_id || location) {
            query_string += ", "
        }
        query_string += ' employee_age = (?) '
        params.push(employee_age)
    }
    if (employee_id) {
        if (employee_name || employee_age || employee_gender || location) {
            query_string += ", "
        }
        query_string += ' employee_id = (?) '
        params.push(employee_id)
    }
    if (location) {
        if (employee_name || employee_age || employee_id || employee_gender) {
            query_string += ", "
        }
        query_string += ' location = (?) '
        params.push(location)
    }

    query_string += "WHERE employee_id = (?)"
    if (!employee_name && !employee_gender && !employee_age && !employee_id && !location) {
        res.redirect("/employee/update?employee_id=" + employee_id + "&error=You must update some fields")
    }
    params.push(employee_id)
    connection.query(query_string, params)
    res.redirect('/employee')
})

module.exports = router;