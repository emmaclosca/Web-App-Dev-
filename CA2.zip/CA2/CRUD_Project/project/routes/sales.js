var express = require('express');
var router = express.Router();
var MySql = require('sync-mysql');
/* this function was adapted from lectururs work */
var connection_details = require("../modules/connection_details")


/* this will render the sales table on the ejs file */
router.get('/', function(req, res, next) {
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var sales = connection.query("SELECT * from sales");


    res.render('sales', {
        sales: sales
    });


});
/* this add function will recieve from the ejs file all the variables we want to add into our sql table for sales and then uses a query to insert them */

router.post('/add', function(req, res, next) {
    var sale_total = req.body.sale_total
    var quantity = req.body.quantity
    var item_name = req.body.item_name
    var store_name = req.body.store_name
    var employee_name = req.body.employee_name
    var customer_name = req.body.customer_name

    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    })
    connection.query("INSERT INTO sales (sale_total, quantity, item_name, store_name, employee_name, customer_name) VALUES ((?), (?), (?), (?), (?), (?));", [sale_total, quantity, item_name, store_name, employee_name, customer_name]);
    res.redirect("/sales");
});
/* this delete function recieves the sale id and then deletes that id from the database along with the row that its connected to,then redirect the user back to the same page  */

router.get('/delete', function(req, res, next) {
    var saleid = req.query.saleid

    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var sales = connection.query("SELECT * from sales");

    res.render('sales', {
        title: 'delete page',
        sales: sales
    });
    connection.query("DELETE FROM sales where saleid = (?);", [saleid])

    res.redirect('/sales')
});
/* this recieves the sale id from the ejs file and also renders the sale info on the page  */

router.get('/update', function(req, res, next) {
    var saleid = req.query.saleid
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var sales = connection.query("SELECT * from sales");

    res.render('sales', {
        sales: sales,
        saleid: saleid
    });

})
/* this update function was adapted from lectururs work */
/* this will recieve all the variables for the data i want to update then pushes that data to the sql table */
router.post('/update', function(req, res, next) {
    var sale_total = req.body.sale_total
    var quantity = req.body.quantity
    var saleid = req.body.saleid
    var item_name = req.body.item_name
    var store_name = req.body.store_name
    var employee_name = req.body.employee_name
    var customer_name = req.body.customer_name
    var connection = new MySql({
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database,
        host: connection_details.host
    })
    var query_string = "UPDATE sales set"
    var params = []
    if (sale_total) {
        query_string += ' sale_total = (?)'
        params.push(sale_total)
    }
    if (quantity) {
        if (sale_total || item_name || store_name || employee_name || customer_name || saleid) {
            query_string += ", "
        }
        query_string += ' quantity = (?) '
        params.push(quantity)
    }
    if (saleid) {
        if (sale_total || item_name || store_name || employee_name || customer_name || quantity) {
            query_string += ", "
        }
        query_string += ' saleid = (?) '
        params.push(saleid)
    }
    if (item_name) {
        if (sale_total || quantity || store_name || employee_name || customer_name || saleid) {
            query_string += ", "
        }
        query_string += ' item_name = (?) '
        params.push(item_name)
    }
    if (store_name) {
        if (sale_total || item_name || quantity || employee_name || customer_name || saleid) {
            query_string += ", "
        }
        query_string += ' store_name = (?) '
        params.push(store_name)
    }
    if (employee_name) {
        if (sale_total || item_name || store_name || quantity || customer_name || saleid) {
            query_string += ", "
        }
        query_string += ' employee_name = (?) '
        params.push(employee_name)
    }
    if (customer_name) {
        if (sale_total || item_name || store_name || employee_name || quantity || saleid) {
            query_string += ", "
        }
        query_string += ' customer_name = (?) '
        params.push(customer_name)
    }


    query_string += "WHERE saleid = (?)"
    if (!sale_total && !quantity && !saleid && !item_name && !store_name && !employee_name && !customer_name) {
        res.redirect("/sales/update?saleid=" + saleid + "&error=You must update some fields")
    }
    params.push(saleid)
    connection.query(query_string, params)
    res.redirect('/sales')
})

module.exports = router;