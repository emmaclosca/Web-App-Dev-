var express = require('express');
var router = express.Router();
var MySql = require('sync-mysql');
/* this function was adapted from lectururs work */
var connection_details = require("../modules/connection_details")

/* this will render the stores table on the ejs file */
router.get('/', function(req, res, next) {
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var stores = connection.query("SELECT * from stores");
    res.render('stores', {
        stores: stores
    });
});

/* this add function will recieve from the ejs file all the variables we want to add into our sql table for stores and then uses a query to insert them */

router.post('/add', function(req, res, next) {
    var store_name = req.body.store_name
    var store_id = req.body.store_id
    var city = req.body.city
    var manager_name = req.body.manager_name
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    })
    connection.query("INSERT INTO stores (store_name,store_id, city, manager_name) VALUES ((?), (?),(?), (?));", [store_name, store_id, city, manager_name]);
    res.redirect("/stores");
})
/* this delete function recieves the store id and then deletes that id from the database along with the row that its connected to,then redirect the user back to the same page  */

router.get('/delete', function(req, res, next) {
    var store_id = req.query.store_id

    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var stores = connection.query("SELECT * from stores");

    res.render('stores', {
        title: 'delete page',
        stores: stores
    });
    connection.query("DELETE FROM stores where store_id = (?);", [store_id])

    res.redirect('/stores')
})
/* this recieves the store id from the ejs file and also renders the store info on the page  */

router.get('/update', function(req, res, next) {
    var store_id = req.query.store_id
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var stores = connection.query("SELECT * from stores");

    res.render('stores', {
        stores: stores,
        store_id: store_id
    });

})
/* this update function was adapted from lectururs work */
/* this will recieve all the variables for the data i want to update then pushes that data to the sql table */
router.post('/update', function(req, res, next) {
    var store_name = req.body.store_name
    var store_id = req.body.store_id
    var city = req.body.city
    var manager_name = req.body.manager_name
    var connection = new MySql({
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database,
        host: connection_details.host
    })
    var query_string = "UPDATE stores set"
    var params = []
    if (store_name) {
        query_string += ' store_name = (?)'
        params.push(store_name)
    }
    if (store_id) {
        if (store_name || city || manager_name) {
            query_string += ", "
        }
        query_string += ' store_id = (?) '
        params.push(store_id)
    }
    if (city) {
        if (store_name || manager_name || store_id) {
            query_string += ", "
        }
        query_string += ' city = (?) '
        params.push(city)
    }
    if (manager_name) {
        if (store_name || city || store_id) {
            query_string += ", "
        }
        query_string += ' manager_name = (?) '
        params.push(manager_name)
    }

    query_string += "WHERE store_id = (?)"
    if (!store_name && !store_id && !city && !manager_name) {
        res.redirect("/stores/update?store_id=" + store_id + "&error=You must update some fields")
    }
    params.push(store_id)
    connection.query(query_string, params)
    res.redirect('/stores')
})

module.exports = router;