var express = require('express');
var router = express.Router();
var MySql = require('sync-mysql');
/* this function was adapted from lectururs work */
var connection_details = require("../modules/connection_details")
/* this will render the products table on the ejs file */

router.get('/', function(req, res, next) {
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var items = connection.query("SELECT * from items");


    res.render('products', {
        items: items
    });


});



/* this add function will recieve from the ejs file all the variables we want to add into our sql table for items and then uses a query to insert them */

router.post('/add', function(req, res, next) {
    var item_name = req.body.item_name
    var item_category = req.body.item_category
    var item_price = req.body.item_price
    var item_id = req.body.item_id
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    })
    connection.query("INSERT INTO items (item_Name, item_category, item_price,item_id) VALUES ((?), (?), (?), (?));", [item_name, item_category, item_price, item_id]);
    res.redirect("/products");
})
/* this delete function recieves the item id and then deletes that id from the database along with the row that its connected to,then redirect the user back to the same page  */

router.get('/delete', function(req, res, next) {
    var item_id = req.query.item_id

    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var items = connection.query("SELECT * from items");

    res.render('products', {
        title: 'delete page',
        items: items
    });

    connection.query("DELETE FROM items where item_id = (?);", [item_id])

    res.redirect('/products')
})
/* this recieves the item id from the ejs file and also renders the item info on the page  */

router.get('/update', function(req, res, next) {
    var item_id = req.query.item_id
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var items = connection.query("SELECT * from items");

    res.render('products', {
        items: items,
        item_id: item_id
    });

})
/* this update function was adapted from lectururs work */
/* this will recieve all the variables for the data i want to update  then pushes that data to the sql table */
router.post('/update', function(req, res, next) {
    var item_name = req.body.item_name
    var item_category = req.body.item_category
    var item_price = req.body.item_price
    var item_id = req.body.item_id
    var connection = new MySql({
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database,
        host: connection_details.host
    })
    var query_string = "UPDATE items set"
    var params = []
    if (item_name) {
        query_string += ' item_name = (?)'
        params.push(item_name)
    }
    if (item_category) {
        if (item_name || item_price || item_id) {
            query_string += ", "
        }
        query_string += ' item_category = (?) '
        params.push(item_category)
    }
    if (item_price) {
        if (item_name || item_category || item_id) {
            query_string += ", "
        }
        query_string += ' item_price = (?) '
        params.push(item_price)
    }
    if (item_id) {
        if (item_name || item_category || item_price) {
            query_string += ", "
        }
        query_string += ' item_id = (?) '
        params.push(item_id)
    }

    query_string += "WHERE item_id = (?)"
    if (!item_name && !item_category && !item_price && !item_id) {
        res.redirect("/products/update?item_id=" + item_id + "&error=You must update some fields")
    }
    params.push(item_id)
    connection.query(query_string, params)
    res.redirect('/products')
})




module.exports = router;