var express = require('express');
var router = express.Router();
var MySql = require('sync-mysql');
/* this function was adapted from lectururs work */
var connection_details = require("../modules/connection_details");

/* this will render the customers table on the ejs file */
router.get('/', function(req, res, next) {
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var customer = connection.query("SELECT * from customer");


    res.render('customer', {
        customer: customer
    });


});

/* this add function will recieve from the ejsfile all the variables we want to add into our sql table for customers and then uses a query to insert them */
router.post('/add', function(req, res, next) {
    var customer_name = req.body.customer_name
    var customer_address = req.body.customer_address
    var customer_id = req.body.customer_id
    var phonenumber = req.body.phonenumber
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    })
    connection.query("INSERT INTO customer (customer_name, customer_address,customer_id, phonenumber) VALUES ((?), (?), (?), (?));", [customer_name, customer_address, customer_id, phonenumber]);
    res.redirect("/customer");
})
/* this delete function recieves the customer id and then deletes that id from the database along with the row that its connected to */
router.get('/delete', function(req, res, next) {
    var customer_id = req.query.customer_id

    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var customer = connection.query("SELECT * from customer");

    res.render('customer', {
        title: 'delete page',
        customer: customer
    });
    connection.query("DELETE FROM customer where customer_id = (?);", [customer_id])

    res.redirect('/customer')
})
/* this recieves the customer id from the ejs file and and also renders the customers table on the page  */
router.get('/update', function(req, res, next) {
    var customer_id = req.query.customer_id
    var connection = new MySql({
        host: connection_details.host,
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database
    });
    var customer = connection.query("SELECT * from customer");

    res.render('customer', {
        customer: customer,
        customer_id: customer_id
    });

})

/* this update function was adapted from lectururs work */
/* this will recieve all the variables for the data i want to update then pushs that data to the sql table */
router.post('/update', function(req, res, next) {
    var customer_name = req.body.customer_name
    var customer_address = req.body.customer_address
    var customer_id = req.body.customer_id
    var phonenumber = req.body.phonenumber
    var connection = new MySql({
        user: connection_details.user,
        password: connection_details.password,
        database: connection_details.database,
        host: connection_details.host
    })
    var query_string = "UPDATE customer set"
    var params = []
    if (customer_name) {
        query_string += ' customer_name = (?)'
        params.push(customer_name)
    }
    if (customer_address) {
        if (customer_name || customer_id || phonenumber) {
            query_string += ", "
        }
        query_string += ' customer_address = (?) '
        params.push(customer_address)
    }
    if (customer_id) {
        if (customer_name || customer_address || phonenumber) {
            query_string += ", "
        }
        query_string += ' customer_id = (?) '
        params.push(customer_id)
    }
    if (phonenumber) {
        if (customer_name || customer_id || customer_address) {
            query_string += ", "
        }
        query_string += ' phonenumber = (?) '
        params.push(phonenumber)
    }


    query_string += "WHERE customer_id = (?)"
    if (!customer_name && !customer_address && !customer_id && !phonenumber) {
        res.redirect("/customer/update?customer_id=" + customer_id + "&error=You must update some fields")
    }
    params.push(customer_id)
    connection.query(query_string, params)
    res.redirect('/customer')
})


module.exports = router;